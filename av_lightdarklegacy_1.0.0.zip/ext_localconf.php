<?php
if(!defined('TYPO3')) { die('Access denied.'); }

$GLOBALS['TYPO3_CONF_VARS']['BE']['stylesheets']['av_lightdarklegacy'] = 'EXT:av_lightdarklegacy/Resources/Public/Css/lightdarkOverride.css';