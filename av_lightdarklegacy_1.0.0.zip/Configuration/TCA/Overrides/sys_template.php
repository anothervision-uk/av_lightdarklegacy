<?php
defined('TYPO3') || die();

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addStaticFile('av_lightdarklegacy', 'Configuration/TypoScript', 'av light-dark Legacy Browsers');